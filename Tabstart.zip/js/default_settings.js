var default_sites = [
  "https://www.twitter.com",
  "https://www.reddit.com",
  "https://www.youtube.com",
  "https://www.google.com",
  "https://www.facebook.com",
  "https://www.github.com",
]

var default_icons = {
  "https://www.facebook.com": "fb",
  "https://www.plus.google.com": "gp",
  "https://www.youtube.com": "yt",
  "https://www.9gag.com": "ng",
  "https://www.mail.google.com": "gmail",
  "https://www.reddit.com": "rd",
  "https://www.google.com": "gg",
  "https://www.yahoo.com": "yh",
  "https://www.drive.google.com": "gd",
  "https://www.digg.com": "dg",
  "https://www.theverge.com": "vg",
  "https://www.twitter.com": "tw",
  "https://www.getpocket.com": "pk",
  "https://www.keep.google.com": "gk",
  "https://www.inbox.google.com": "ix",
  "https://www.ello.co": "el",
  "https://www.slack.com": "sk",
  "https://www.lavandadelpatio.es": "lv",
  "https://www.google.es": "gg",
  "https://www.github.com": "gh"
}

