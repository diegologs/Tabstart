# <img src="img/logo.png" width="24" height="24" alt="Tabstart"> Tabstart

### A new tab replacement

Tabstart is a replacement for new tabs in firefox and chrome. It displays the current time, and icons for your popular sites. If you don't like the 
default sites you can add or delete the sites whenever you want. It also shows background wallpapers of a popular subrredit.

![Tabstart screenshot](https://i.imgur.com/LEPDYM2.jpg)

<a href="changelog.md">CHANGELOG</a>
<a href="credits.md">CREDITS</a>
