# Changelog

1.0 (January 2018)
    
    - Random background wallpaper display from reddit.com/r/wallpaper
    - Current time display
    - Display sites with their logo and url
    - User can delete or add new sites
